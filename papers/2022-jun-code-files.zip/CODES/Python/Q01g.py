# Q01g

storedLetter = "g"
letter = input("Input a letter ")
# Letter converted to lower case
letter = letter.lower()

# Amend the code by completing the if statement
if :
    
elif :
    
else:
    