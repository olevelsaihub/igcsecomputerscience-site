# Q03

#  Initialise variables


#  Print prompt and take number of textbooks required


#  Generate and display the price per textbook and the total cost