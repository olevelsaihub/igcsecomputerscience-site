
TAX = 0.05      # This is 5%

grossAmt = 0.0
netAmt = 0.0

def calcResult (inGross):
    net = inGross * (1 - TAX)
    return (net)

grossAmt = float (input ("Enter the gross amount: "))
if (grossAmt < 10.0) or (grossAmt > 200.0):
    print ("Invalid input")
else:
    netAmt = calcResult (grossAmt)
    print ("Your net amount is", netAmt)

