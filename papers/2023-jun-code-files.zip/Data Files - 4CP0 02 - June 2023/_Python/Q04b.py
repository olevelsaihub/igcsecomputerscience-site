# Q04b

# ---------------------------------------------------------
# Write your code below this line