# Q06

tbl_breed = ["Red Chittagong", "Sussex", "Dexter", "Abondance",
             "Sahiwal", "Vorderwald", "Ayrshire", "Jersey",
             "Randall", "Alderney", "Carora", "Gloucester"]
tbl_rating = [1, 2, 3, 2, 3, 1, 2, 1, 2, 1, 3, 2]
tbl_count = [6, 3, 8, 7, 6, 4, 3, 7, 3, 3, 4, 7]
tbl_volume = [7.5, 5.7, 11.4, 11.4,
              22.0, 15.2, 21.0, 18.3,
              19.0, 9.0, 23.1, 16.0]
tbl_dailyVolume = []

# ----------------------------------------------
# Write your code below this line
