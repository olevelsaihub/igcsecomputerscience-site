// Q03b

package q03b;

import java.util.Scanner;

public class Q03b 
{
    public static void main(String[] args) 
    {
        // ------------------------------------------------
        // Write your code below this line
        
        
    }
}
