package q01b;

import java.util.Scanner;

public class Q01b 
{
    static final double TAX = 0.05;     // This is 5%
    
    static double calcResult(double inGross)
    {
        double net = inGross * (1 - TAX);
        return (net);
    }
            
    public static void main(String[] args) 
    {      
        double grossAmt = 0.0;
        double netAmt = 0.0;
           
        Scanner myScanner = new Scanner (System.in);

        System.out.print("Enter the gross amount: ");
        grossAmt = Double.parseDouble (myScanner.nextLine());
        if ((grossAmt < 10.0) || (grossAmt > 200.0))
        {
            System.out.println("Invalid input");
        }
        else
        {
            netAmt = calcResult(grossAmt);
            System.out.println("Your net amount is " + Double.toString(netAmt));
        }
    } 
}
