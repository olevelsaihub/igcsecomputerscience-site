// Q04b

package q04b;

import java.io.Console;
import java.util.Scanner;

public class Q04b
{
    public static void main(String[] args) 
    {
        // ------------------------------------------------------
        // Write your code below this line
        
 
    }
}
