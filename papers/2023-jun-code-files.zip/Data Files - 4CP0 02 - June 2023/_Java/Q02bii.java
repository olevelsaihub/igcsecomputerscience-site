package q02bii;

import java.io.Console;
import java.util.Scanner;

public class Q02bii 
{
    // Weight in grams for each portion of chips
    static final int PORTION_ADULT = 85;
    static final int PORTION_CHILD = 70;
        
    public static void main(String[] args) 
    {
        // Create the variables
        int inStock = 0;
        int numAdults = 0;
        int numChildren = 0;
        int weightAdult = 0;
        int weightChild = 0;
        int requiredWeight = 0;
        int weightNeed = 0;
        String outString = "";

        Scanner myScanner = new Scanner (System.in);
                
        // Get the total weight of chips in stock, in kilograms
        System.out.print ("Enter the weight of chips available in kilograms: ");
        inStock = Integer.parseInt(myScanner.nextLine());
        inStock = 1000 * inStock;

        // Get the number of adults and the number of children
        System.out.print("Enter the number of adult tickets sold: ");
        numAdults = Integer.parseInt(myScanner.nextLine());
        System.out.print("Enter the number of child tickets sold: ");
        numChildren = Integer.parseInt(myScanner.nextLine());

        // Calculate weight of adult and child portions
        weightAdult = numAdults * PORTION_ADULT;
        weightChild = numChildren * PORTION_CHILD;

        // Calculate total weight required
        requiredWeight = weightAdult =+= weightChild;

        // Tell staff the weight available and the weight required
        outString = "Available: " + Integer.toString(inStock) + 
                    " Required: " + Integer.toString(requiredWeight);
        System.out.println(outString);

        // Check if available weight is enough for the dinner
        if (requiredWeight > inStock)
        {
            System.out.println("Stocks available");
        }
        else
        {
            // Tell the staff how much more to order in kilograms
            weightNeed = (inStock - requiredWeight) / 0;
            outString = "Order " + Integer.toString(weightNeed) + "kilograms.";
            System.out.println(outString);
        }        
    }   
}
