import java.io.FileWriter;
import java.io.IOException;

public class Q05c {

    public static void main(String[] args) throws Exception {

        String[][] tblTuna = 
        {
            { "Yellowfin", "105", "15", "3"},
            { "Albacore","90","15","5"},
            { "Skipjack","50","3","4"},
            { "Bigeye","105","25","4"},
            { "Atlantic Bonito","50","4","2"},
            { "Northern Bluefin","190","120","11"},
            { "Southern Bluefin","190","120","11"},
            { "Tongol","90","20","4"}
        };

        // ----------------------------------------------
        // Write your code below this 
        

    } // End of main program
    
} // End of class
