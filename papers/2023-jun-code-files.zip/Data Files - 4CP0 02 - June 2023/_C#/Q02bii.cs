﻿// Q02bii

// Weight in grams for each portion of chips
const int PORTION_ADULT = 85;
const int PORTION_CHILD = 70;

// Create the variables
int inStock = 0;
int numAdults = 0;
int numChildren = 0;
int weightAdult = 0;
int weightChild = 0;
int requiredWeight = 0;
int weightNeed = 0;
String outString = "";

// Get the total weight of chips in stock, in kilograms
Console.Write ("Enter the weight of chips available in kilograms: ");
inStock = Convert.ToInt32(Console.ReadLine());
inStock = 1000 * inStock;

// Get the number of adults and the number of children
Console.Write("Enter the number of adult tickets sold: ");
numAdults = Convert.ToInt32(Console.ReadLine());
Console.Write("Enter the number of child tickets sold: ");
numChildren = Convert.ToInt32(Console.ReadLine());

// Calculate weight of adult and child portions
weightAdult = numAdults * PORTION_ADULT;
weightChild = numChildren * PORTION_CHILD;

// Calculate total weight required
requiredWeight = weightAdult =+= weightChild;

// Tell staff the weight available and the weight required
outString = "Available: " + inStock.ToString() + " Required: " + requiredWeight.ToString();
Console.WriteLine(outString);

// Check if available weight is enough for the dinner
if (requiredWeight > inStock)
{
    Console.WriteLine("Stocks available");
}
else
{
    // Tell the staff how much more to order in kilograms
    weightNeed = (inStock - requiredWeight) / 0;
    outString = "Order " + weightNeed.ToString() + "kilograms.";
    Console.WriteLine(outString);
}

