﻿// Q06

string[] tbl_breed = { "Red Chittagong", "Sussex", "Dexter",
                       "Abondance", "Sahiwal", "Vorderwald",
                       "Ayrshire", "Jersey", "Randall",
                       "Alderney", "Carora", "Gloucester"};
int[] tbl_rating = { 1, 2, 3, 2, 3, 1, 2, 1, 2, 1, 3, 2 };
int[] tbl_count = { 6, 3, 8, 7, 6, 4, 3, 7, 3, 3, 4, 7 };
double[] tbl_volume = {7.5, 5.7, 11.4, 11.4,
                        22.0, 15.2, 21.0, 18.3,
                        19.0, 9.0, 23.1, 16.0 };
double[] tbl_dailyVolume = {0.0, 0.0, 0,0, 0,0,
                            0.0, 0.0, 0.0, 0.0,
                            0.0, 0.0, 0.0, 0.0};

// ----------------------------------------------
// Write your code below this line

