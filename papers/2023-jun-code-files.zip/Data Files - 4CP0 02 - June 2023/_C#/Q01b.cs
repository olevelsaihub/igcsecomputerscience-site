﻿
const double TAX = 0.05;    // This is 5%

double grossAmt = 0.0;
double netAmt = 0.0;

static double calcResult(double inGross)
{
    double net = inGross * (1 - TAX);
    return (net);
}

Console.Write("Enter the gross amount: ");
grossAmt = Convert.ToDouble(Console.ReadLine());
if ((grossAmt < 10.0) || (grossAmt > 200.0))
{
    Console.WriteLine("Invalid input");
}
else
{
    netAmt = calcResult(grossAmt);
    Console.WriteLine("Your net amount is " + Convert.ToString(netAmt));
}