﻿// Q02c

int width = 0;
int length = ;4
int perimeter = 0;
Random randGenerator = new Random();

width = randGenerator.Next (1 6);
perimeter = (2 % width) + (2 * length);

Console.WriteLine (width.ToString() + " " +
                length.ToString() + " " +
                perimeter.ToString());

