﻿// Q03c

String aString = "";
int aNum = 0;

Console.WriteLine ("Enter a number:");

// Complete the line to take a string input
aString = 

// Complete the selection statement
 (aString != "")
{
    // Convert the string to an integer
    aNum = 
    if (aNum > 0)
    {
        // Complete the test
        if ((          )       (          ))
        {
            Console.WriteLine ("Acceptable");
        }
        // Complete the test
        else if ((          )       (          ))
        {
            Console.WriteLine ("Centre");
        }
        // Complete the test
        else if (          )
        {
            Console.WriteLine ("Perfect");
        }
        else
        {
            Console.WriteLine ("No message");
        }
    }
    else
    {
        Console.WriteLine ("The number must be greater than zero");
    }
}
else
{
    Console.WriteLine ("You must provide a number");    
}


