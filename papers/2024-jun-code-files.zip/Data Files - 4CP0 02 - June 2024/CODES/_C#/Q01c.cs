﻿// Q01c

int count = 0;
int total = 0;
int subTotal = 0;

// Loop for 50 times
while (count < 50)
{
    total = total + count;

    if ((count > 10) && (count < 20))
    {
        subTotal = subTotal + count;
    }
    count = count + 1;
}

Console.WriteLine (total.ToString() + 
                   " " + subTotal.ToString());
