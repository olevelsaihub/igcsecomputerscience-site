﻿// Q06

String[,] tblWords = {{"apple", "banana"},
                        {"wrist", "leg"},
                        {"blue", "yellow"},
                        {"speaker", "keyboard"},
                        {"lavender", "tulip"},
                        {"pencil", "chalk"},
                        {"apartment", "house"},
                        {"bottom", "top"},
                        {"snow", "fog"},
                        {"beach", "mountain"},
                        {"", ""}};

String word1 = "newspaper";
String word2 = "book";

// ----------------------------------------------
// Write your code below this line


