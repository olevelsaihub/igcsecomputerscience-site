﻿// Q01b

// Complete the line to initialise myName to an empty string
String myName = 

// Add a line to create an integer variable called myAge and
//     initialise myAge to 0


Console.WriteLine ("Enter your name: ");
myName = Console.ReadLine();
Console.WriteLine ("Enter your age: ");
myAge = Convert.ToInt32 (Console.ReadLine());

// Complete the test to check if the age is less than 30
if (myAge  30)
{
    // Add a line to display a message that says "Welcome"
    
}

