﻿// Q04c

namespace Q04c
{
    class Q04c
    {
        static String genNewKey (String pString, int pNum)
        {
            String newKey;      // Make new word here

            // Write your code below this line

        }

        static void Main(string[] args) 
        {
            String myNewKey = "";
            int myNumber = 0;
            String myString = "";

            Console.WriteLine ("Enter a string:");
            myString = Console.ReadLine();
            Console.WriteLine ("Enter a whole number: ");
            myNumber = Convert.ToInt32(Console.ReadLine());

            if (myString.Length != 4)
            {
                Console.WriteLine ("String must be four characters");
            }
            else
            {
                Console.WriteLine ("Original: " + myString +
                            " " + myNumber.ToString());

                // Complete the call to the subprogram                            
                myNewKey = 
                Console.WriteLine ("New: " + myNewKey);
            }
        }
    }
}


