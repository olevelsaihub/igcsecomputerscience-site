// Q05c

import java.io.FileReader;
import java.io.BufferedReader;

public class Q05c
{      
    public static void main(String[] args) throws Exception
    {
        String inputFile = "Sales.txt";    // Output file name
        String comma = ",";                 // Use as a constant

        int subTotal = 0;               // Subtotal for each line
        int grandTotal = 0;             // Running total
        String line;                    // Line read from file

        // Complete the code to open the file for reading
        String fullPath = "C:\\Q05c";
        inputFile = fullPath + "\\" + inputFile;
        BufferedReader theFile = 
        
        // Complete the code to read the first line of the input file 
        line = theFile.

        // Loop as long as the line is not null
        while (line != null)
        {
            // Complete the code to split the line into a set of five strings
            String[] stringSales = line.

            subTotal = 0;
            // Add code to sum up each value in the set of five strings            

                
            // Add code to display the subtotal for the line
            

            // Add code to calculate the running total
            

            // Complete the code to read the next line of the file
            line = theFile.
        }

        // Add code to display the total of all lines in the file
        

        // Complete the code to close the opened file
        theFile.
    }
}