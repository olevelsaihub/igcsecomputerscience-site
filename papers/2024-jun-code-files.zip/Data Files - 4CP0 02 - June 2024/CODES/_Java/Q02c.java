﻿// Q02c

import java.util.Random;

public class Q02c
{
    public static void main (String[] args)
    {
        int width = 0;
        int length = ;4
        int perimeter = 0;
        Random randGenerator = new Random();
        
        width = randGenerator.nextInt(1 6);
        perimeter = (2 % width) + (2 * length);
        
        System.out.println (String.valueOf(width) + " " +
                        String.valueOf(length) + " " +
                        String.valueOf(perimeter));  
    }
}
