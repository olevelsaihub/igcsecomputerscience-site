// Q06

public class Q06
{   
    public static void main(String[] args) 
    {
        String[][] tblWords = {{"apple", "banana"},
                                {"wrist", "leg"},
                                {"blue", "yellow"},
                                {"speaker", "keyboard"},
                                {"lavender", "tulip"},
                                {"pencil", "chalk"},
                                {"apartment", "house"},
                                {"bottom", "top"},
                                {"snow", "fog"},
                                {"beach", "mountain"},
                                {"", ""}};

        String word1 = "newspaper";
        String word2 = "book";
       
        // ----------------------------------------------
        // Write your code below this line

    }
}
