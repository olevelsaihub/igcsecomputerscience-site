// Q04c

import java.util.Scanner;

public class Q04c
{
    static String genNewKey (String pString, int pNum)
    {
        String newKey;      // Make new word here

        // Write your code below this line
       
    }

    public static void main(String[] args) 
    {
        String myNewKey = "";
        int myNumber = 0;
        String myString = "";
        Scanner myKeyboard = new Scanner (System.in);

        System.out.println ("Enter a string:");
        myString = myKeyboard.nextLine();
        System.out.println ("Enter a whole number: ");
        myNumber = myKeyboard.nextInt();

        if (myString.length() != 4)
        {
            System.out.println ("String must be four characters");
        }
        else
        {
            System.out.println ("Original: " + myString +
                        " " + String.valueOf(myNumber));

            // Complete the call to the subprogram                            
            myNewKey = 
            System.out.println ("New: " + myNewKey);
        }
    }
}

