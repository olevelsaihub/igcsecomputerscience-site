// Q03b


public class Q03b
{
    public static void main (String[] args)
    {
        String starNames[] = {"Alasia", "Beid", "Castor", "Denebola",
                                "Electra", "Fafnir", "Gudja", "Haedus",
                                "Izar", "Jishui", "Kang", "Lich", 
                                "Maia", "Nahn", "Ogma", "Peacock"};

        // Write your code here

    }
}
