// Q01b

import java.util.Scanner;
public class Q01b
{
    public static void main (String[] args)
    {
        Scanner myKeyboard = new Scanner (System.in);

        // Complete the line to initialise myName to an empty string
        String myName =

        // Add a line to create an integer variable called myAge and
        //     initialise myAge to 0
        

        System.out.println ("Enter your name: ");
        myName = myKeyboard.nextLine();
        System.out.println ("Enter your age: ");
        myAge = Integer.parseInt (myKeyboard.nextLine());

        // Complete the test to check if the age is less than 30
        if (myAge  30)
        {
            // Add a line to display a message that says "Welcome"
            
        }  
    }
}
