﻿// Q03c

import java.util.Scanner;

public class Q03c
{
    public static void main (String[] args)
    {
        String aString = "";
        int aNum = 0;
        Scanner myKeyboard = new Scanner (System.in);

        System.out.println ("Enter a number:");
        
        // Complete the line to take a string input
        aString = 

        // Complete the selection statement
         (aString != "")
        {
            // Convert the string to an integer
            aNum = 
            if (aNum > 0)
            {
                // Complete the test
                if ((          )       (          ))
                {
                    System.out.println ("Acceptable");
                }
                // Complete the test                
                else if ((          )       (          ))
                {
                    System.out.println ("Centre");
                }
                // Complete the test
                else if (          )
                {
                    System.out.println ("Perfect");
                }
                else
                {
                    System.out.println ("No message");
                }
            }
            else
            {
                System.out.println ("The number must be greater than zero");
            }
        }
        else
        {
            System.out.println ("You must provide a number");    
        }        
    }
}


