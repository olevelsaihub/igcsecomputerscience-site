// Q01c

public class Q01c
{
    public static void main (String[] args)
    {
        int count = 0;
        int total = 0;
        int subTotal = 0;

        // Loop for 50 times
        while (count < 50)
        {
            total = total + count;

            if ((count > 10) && (count < 20))
            {
                subTotal = subTotal + count;
            }
            count = count + 1;
        }
        System.out.println (String.valueOf (total) + 
                            " " + String.valueOf (subTotal));
    }
}